﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace ToolInspectV1.Log
{
    public class LogWriter
    {
        private string m_exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public LogWriter()
        {
        }
       
        public void WriteFile(string logMessage, string fileName)
        {
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileName))
            {
                w.Write(logMessage);
            }
            
        }
        public void LogDateFile(string fileName)
        {
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileName))
            {
                w.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());
                w.WriteLine("...............................");
            }
           
        }
        public void LogFile(string logMessage, string fileName)
        {
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileName))
            {
                w.WriteLine(logMessage);

            }
        }

        public void WriteFileLine(string logMessage, string fileName)
        {
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileName))
            {
                w.Write(logMessage);
                w.WriteLine();
            }
            

        }
       
       
    }
}
