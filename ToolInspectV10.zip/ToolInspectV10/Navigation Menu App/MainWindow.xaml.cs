﻿
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.Http;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using ToolInspectV1.Log;
using VirusTotalNet;
using VirusTotalNet.Objects;
using VirusTotalNet.ResponseCodes;
using VirusTotalNet.Results;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Automation;
using NDde.Client;
using System.Threading;
using UIAutomationClient;
using TreeScope = UIAutomationClient.TreeScope;
using System.Drawing.Printing;
using System.Security.Cryptography.Xml;
using System.Management.Automation.Runspaces;
using System.Management.Automation;
using System.Security.Cryptography.X509Certificates;
using Microsoft.VisualBasic;
using RoundRobin;
using System.Security.Cryptography;

namespace Navigation_Menu_App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string securityRP = "InfoSecurityRP.txt";
        string fileScanUrlLog = "ScanUrl.txt";
        string fileScanMalwareLog = "ScanMalware.txt";
        string ScanDigitalSign = "ScanDigitalSign.txt";
        string hardwardInfo = "hardwardInfo.txt";
        string osSoftwareInfo = "osSoftwareInfo.txt";
        List<cMainboardInfo> listMainboard = new List<cMainboardInfo>();
        List<cRamInfo> listRam = new List<cRamInfo>();
        List<cCpuInfo> listCpu = new List<cCpuInfo>();
        List<cOSInfo> listOs = new List<cOSInfo>();
        List<cSoftwareInfo> listSoftware = new List<cSoftwareInfo>();
        List<cServiceInfo> listService = new List<cServiceInfo>();
        List<cPPrInfo> listPPr = new List<cPPrInfo>();
        List<cDriveInfo> listDrive = new List<cDriveInfo>();
        List<cSignInfo> listScanSign = new List<cSignInfo>();


        string m_exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        ulong gb = 1024 * 1024 * 1024;
        List<cScanUrlInfo> listUrl = new List<cScanUrlInfo>();
        List<cProcessInfo> listFile = new List<cProcessInfo>();
        public class cMainboardInfo
        {
            public string sMainboardItem { get; set; }
            public string sMainboardValue { get; set; }

        }
        public class cScanUrlInfo
        {
            public string sUrl { get; set; }
            public string sDetected { get; set; }

        }
        public class cOSInfo
        {
            public string sItem { get; set; }
            public string sValue { get; set; }

        }
        public class cProcessInfo
        {
            public string sId { get; set; }
            public string sName { get; set; }

            public string sDetected { get; set; }
            public string sValue { get; set; }

        }
        public class cFileScan
        {
            public string sId { get; set; }
            public string sName { get; set; }

            public string sValue { get; set; }

        }
        public class FileScanComparer : IEqualityComparer<cFileScan>
        {
            public bool Equals(cFileScan x, cFileScan y)
            {
                return x.sValue == y.sValue;
            }
            public int GetHashCode(cFileScan obj)
            {
                return obj.sValue.GetHashCode();
            }
        }
        public class cRamInfo
        {
            public string sRamItem { get; set; }
            public string sRamValue { get; set; }

        }

        public class cSignInfo
        {
            public string sSignPath { get; set; }
            public string sSignState { get; set; }

        }
        public class cPPrInfo
        {
            public string sPPrItem { get; set; }
            public string sPPrValue { get; set; }

        }
        public class cDriveInfo
        {
            public string sDriveItem { get; set; }
            public string sDriveValue { get; set; }

        }
        public class cCpuInfo
        {
            public string sCpuItem { get; set; }
            public string sCpuValue { get; set; }

        }

        public class cSoftwareInfo
        {
            public string sName { get; set; }
            public string sVersion { get; set; }

            public string sInstallPath { get; set; }

        }

        public class cServiceInfo
        {
            public string sName { get; set; }

            public string sStatus { get; set; }
            public string sPID { get; set; }
            public string sDescription { get; set; }


        }

       
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private static string ConvertToDateTime(string unconvertedataime)
        {
            string convertedataime = "";
            string year = unconvertedataime.Substring(0, 4);
            string month = unconvertedataime.Substring(4, 2);
            string date = unconvertedataime.Substring(6, 2);
            convertedataime = date + "-" + month + "-" + year;
            return convertedataime;
        }
        private static string ConvertToDateTimeSeconds(string unconvertedataime)
        {
            string convertedataime = "";
            string year = unconvertedataime.Substring(0, 4);
            string month = unconvertedataime.Substring(4, 2);
            string date = unconvertedataime.Substring(6, 2);
            string hours = unconvertedataime.Substring(8, 2);
            string minutes = unconvertedataime.Substring(10, 2);
            string seconds = unconvertedataime.Substring(12, 2);

            convertedataime = date + "-" + month + "-" + year + " " + hours + ":" + minutes + ":" + seconds;
            return convertedataime;
        }
        private string SanitizeMemoryGpuType(UInt16 i)
        {
            string result = string.Empty;

            switch (i)
            {
                case 1:
                    result = "Other";
                    break;
                case 2:
                    result = "Unknown";
                    break;
                case 3:
                    result = "VRAM";
                    break;
                case 4:
                    result = "DRAM";
                    break;
                case 5:
                    result = "SRAM";
                    break;
                case 6:
                    result = "WRAM";
                    break;
                case 7:
                    result = "EDO RAM";
                    break;
                case 8:
                    result = "Burst Synchronous DRAM";
                    break;
                case 9:
                    result = "Pipelined Burst SRAM";
                    break;
                case 10:
                    result = "CDRAM";
                    break;
                case 11:
                    result = "3DRAM";
                    break;
                case 12:
                    result = "SDRAM";
                    break;
                case 13:
                    result = "SGRAM";
                    break;
            }

            return result;
        }
        private void Mainboard_Click(object sender, RoutedEventArgs e)
        {
            listMainboard.Clear();
            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;
            

            MainboardFn();
            Lv_MainboardInfo.ItemsSource = listMainboard;
            Lv_MainboardInfo.Visibility = Visibility.Visible;

        }
        private void MainboardFn()
        {
            string mainboardQuery = string.Format("SELECT * from Win32_BaseBoard");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(mainboardQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject mainboard in coll)
                    {
                        foreach (PropertyData property in mainboard.Properties)
                        {
                            if (property.Value != null)
                            {
                                listMainboard.Add(new cMainboardInfo() { sMainboardItem = "Mainboard." + property.Name, sMainboardValue = Convert.ToString(property.Value) });

                            }

                        }

                        try
                        {
                            ManagementObjectSearcher searcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_IDEController");
                            foreach (ManagementObject mo2 in searcher2.Get())
                            {
                                if (mo2.Properties["Description"].Value != null)
                                {
                                    listMainboard.Add(new cMainboardInfo() { sMainboardItem = "Mainboard." + "Chipset", sMainboardValue = Convert.ToString(mo2.Properties["Description"].Value) });

                                }

                            }
                        }
                        catch { }

                        try
                        {
                            ManagementObjectSearcher searcher3 = new ManagementObjectSearcher("SELECT * FROM Win32_IDEController");
                            foreach (ManagementObject mo3 in searcher3.Get())
                            {
                                if (mo3.Properties["RevisionNumber"].Value != null)
                                {
                                    listMainboard.Add(new cMainboardInfo() { sMainboardItem = "Mainboard." + "Revision", sMainboardValue = Convert.ToString(mo3.Properties["RevisionNumber"].Value) });

                                }

                            }
                        }
                        catch { }

                        try
                        {
                            ManagementObjectSearcher searcher4 = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem");
                            foreach (ManagementObject mo4 in searcher4.Get())
                            {
                                if (mo4.Properties["Model"].Value != null)
                                {
                                    listMainboard.Add(new cMainboardInfo() { sMainboardItem = "Mainboard." + "SystemModel ", sMainboardValue = Convert.ToString(mo4.Properties["Model"].Value) });

                                }

                            }
                        }
                        catch { }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            try
            {
                int i = 0;
                string nwQuery = string.Format("SELECT * from Win32_NetworkAdapter");

                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(nwQuery))
                using (ManagementObjectCollection coll = searcher.Get())
                {
                    try
                    {
                        foreach (ManagementObject nw in coll)
                        {
                            i++;
                            foreach (PropertyData property in nw.Properties)
                            {
                                if (property.Value != null)
                                {
                                    listMainboard.Add(new cMainboardInfo() { sMainboardItem = $"NetworkAdapter{i}." + property.Name, sMainboardValue = Convert.ToString(property.Value) });

                                }

                            }
                        }
                    }
                    catch (ManagementException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch { }

            try
            {
                string biosQuery = string.Format("SELECT * from Win32_BIOS");

                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(biosQuery))
                using (ManagementObjectCollection coll = searcher.Get())
                {
                    try
                    {
                        foreach (ManagementObject bios in coll)
                        {
                            foreach (PropertyData property in bios.Properties)
                            {
                                if (property.Value != null)
                                {
                                    listMainboard.Add(new cMainboardInfo() { sMainboardItem = "BIOS." + property.Name, sMainboardValue = Convert.ToString(property.Value) });

                                }

                            }
                        }
                    }
                    catch (ManagementException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch { }

        }
        private void Hardware_Report_Click(object sender, RoutedEventArgs e)
        {
            string[] filePaths = Directory.GetFiles(m_exePath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(hardwardInfo))
                {
                    File.Delete(hardwardInfo);
                }
            }

            using (StreamWriter w = File.AppendText(m_exePath + "\\" + hardwardInfo))
            {
                w.WriteLine("=========================Hardware Info ================");
                w.WriteLine();
                
                if (listMainboard.Count <= 0)
                {
                    MainboardFn();
                }
                w.WriteLine("---------------------Mainboard--------------------------");
                foreach (cMainboardInfo mainBoard in listMainboard)
                {
                    w.WriteLine(mainBoard.sMainboardItem + ": \t " + mainBoard.sMainboardValue);
                }

                if (listCpu.Count <= 0)
                {
                    CpuFn();
                }
                w.WriteLine("---------------------CPU--------------------------");
                foreach (cCpuInfo cpu in listCpu)
                {
                    w.WriteLine(cpu.sCpuItem + ": \t " + cpu.sCpuValue);
                }

                if (listRam.Count <= 0)
                {
                    RamFn();
                }
                w.WriteLine("---------------------Ram--------------------------");
                foreach (cRamInfo ram in listRam)
                {
                    w.WriteLine(ram.sRamItem + ": \t " + ram.sRamValue);
                }

                if (listDrive.Count <= 0)
                {
                    DriveFn();
                }
                w.WriteLine("---------------------Driver--------------------------");
                foreach (cDriveInfo drive in listDrive)
                {
                    w.WriteLine(drive.sDriveItem + ": \t " + drive.sDriveValue);
                }

                if (listPPr.Count <= 0)
                {
                    PeripheralsFn();
                }
                w.WriteLine("---------------------Peripherals--------------------------");
                foreach (cPPrInfo ppr in listPPr)
                {
                    w.WriteLine(ppr.sPPrItem + ": \t " + ppr.sPPrValue);
                }
            }
            
            MessageBox.Show("Done");
        }
        private void OsInfoFn()
        {
            string installDate_os, lastBootTime_os, localeDateTime_os;
            string lang = "";
            uint a_os;
            ManagementObjectSearcher osQuery = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
            ManagementObjectCollection osCol = osQuery.Get();

            foreach (ManagementObject obj in osCol)
            {
                listOs.Add(new cOSInfo() { sItem = "Computer Name", sValue = obj["csname"].ToString() });
                listOs.Add(new cOSInfo() { sItem = "User ", sValue = obj["RegisteredUser"].ToString() });
                listOs.Add(new cOSInfo() { sItem = "OS name ", sValue = obj["Caption"].ToString() });
                listOs.Add(new cOSInfo() { sItem = "Architecture ", sValue = obj["OSArchitecture"].ToString() });
                listOs.Add(new cOSInfo() { sItem = "Version ", sValue = obj["Version"].ToString() });
                listOs.Add(new cOSInfo() { sItem = "Build Number ", sValue = obj["BuildNumber"].ToString() });


                a_os = Convert.ToUInt32(obj["OSLanguage"]);
                switch (a_os)
                {
                    case 1033:
                        lang = "English-United States";
                        break;
                    case 9:
                        lang = "English";
                        break;
                    case 1081:
                        lang = "Hindi";
                        break;
                    case 2057:
                        lang = "English–United Kingdom";
                        break;
                    default:
                        lang = "none";
                        break;
                }
                listOs.Add(new cOSInfo() { sItem = "Installed Language ", sValue = lang });




                if (Convert.ToString(obj["Locale"]) == "0409")
                {
                    listOs.Add(new cOSInfo() { sItem = "System Locale", sValue = "en-US" });

                }

                installDate_os = Convert.ToString(obj["InstallDate"]);
                {
                    listOs.Add(new cOSInfo() { sItem = "Install Date", sValue = ConvertToDateTimeSeconds(installDate_os) });

                }

                lastBootTime_os = Convert.ToString(obj["LastBootUpTime"]);
                {
                    listOs.Add(new cOSInfo() { sItem = "Last Boot Up Time", sValue = ConvertToDateTimeSeconds(lastBootTime_os) });
                }

                localeDateTime_os = Convert.ToString(obj["LocalDateTime"]);
                {
                    listOs.Add(new cOSInfo() { sItem = "Local Date Time", sValue = ConvertToDateTimeSeconds(localeDateTime_os) });
                }


            }
        }
        private void OSInfo_Click(object sender, RoutedEventArgs e)
        {
            listOs.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;


            //listItem.Add(new cOSInfo() {sItem ="OSName", sValue = "Windows 11" });

            //Lv_Info.ItemsSource = listItem;

            OsInfoFn();

            Lv_OSInfo.ItemsSource = listOs;
            Lv_OSInfo.Visibility = Visibility.Visible;

        }

        private void SoftwareFn()
        {
            var key = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall");


            foreach (var v in key.GetSubKeyNames())
            {
                string keyName = key + "\\" + v;
                var displayName = Registry.GetValue(keyName, "DisplayName", null);

                if (displayName != null)
                {
                    string sVer = "", sInstall = "";
                    var ver = Registry.GetValue(keyName, "DisplayVersion", null);
                    if (ver != null)
                    {
                        sVer = ver.ToString();
                    }
                    var install = Registry.GetValue(keyName, "InstallLocation", null);

                    if (install != null)
                    {
                        sInstall = install.ToString();
                    }
                    listSoftware.Add(new cSoftwareInfo() { sName = displayName.ToString(), sVersion = sVer, sInstallPath = sInstall });
                }
            }
        }
        private void Software_Click(object sender, RoutedEventArgs e)
        {
            listSoftware.Clear();
            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;

            SoftwareFn();

            Lv_SoftwareInfo.ItemsSource = listSoftware;
            Lv_SoftwareInfo.Visibility = Visibility.Visible;

        }

        private void OS_SoftwareRp_Click(object sender, RoutedEventArgs e)
        {
            string[] filePaths = Directory.GetFiles(m_exePath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(hardwardInfo))
                {
                    File.Delete(hardwardInfo);
                }
            }

            using (StreamWriter w = File.AppendText(m_exePath + "\\" + osSoftwareInfo))
            {
                w.WriteLine("=========================Software Info ================");
                w.WriteLine();

                if (listOs.Count <= 0)
                {
                    OsInfoFn();
                }
                w.WriteLine("---------------------OS--------------------------");
                foreach (cOSInfo os in listOs)
                {
                    w.WriteLine(os.sItem + ": \t " + os.sValue);
                }

                if (listSoftware.Count <= 0)
                {
                    SoftwareFn();
                }
                w.WriteLine("---------------------Software--------------------------");
                foreach (cSoftwareInfo sw in listSoftware)
                {
                    w.WriteLine(sw.sName + "| \t " + sw.sVersion + "| \t " + sw.sInstallPath);
                }

                if (listService.Count <= 0)
                {
                    ServiceFn();
                }
                w.WriteLine("---------------------Service--------------------------");
                foreach (cServiceInfo service in listService)
                {
                    w.WriteLine(service.sName + "| \t " + service.sPID + "| \t " + service.sStatus + "|\t " + service.sDescription);
                }

            }
                //string installDate_os, lastBootTime_os, localeDateTime_os;
                //string lang = "";
                //uint a_os;
                //string os = "======OPERATING SYSTEM======\n";
                //string software = "======SOFTWARE INFO======\n";
                //string sService = "======SERVICE INFO======\n";
                //ManagementObjectSearcher osQuery = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
                //ManagementObjectCollection osCol = osQuery.Get();

                //foreach (ManagementObject obj in osCol)
                //{
                //    os += "Computer Name: " + obj["csname"] + "\n";
                //    os += "User: " + obj["RegisteredUser"] + "\n";
                //    os += "OS name:" + obj["Caption"] + " " + obj["OSArchitecture"] + " Version " + obj["Version"] + " (Build " + obj["BuildNumber"] + ")" + "\n";
                //    a_os = Convert.ToUInt32(obj["OSLanguage"]);
                //    switch (a_os)
                //    {
                //        case 1033:
                //            lang = "English-United States";
                //            break;
                //        case 9:
                //            lang = "English";
                //            break;
                //        case 1081:
                //            lang = "Hindi";
                //            break;
                //        case 2057:
                //            lang = "English–United Kingdom";
                //            break;
                //        default:
                //            lang = "none";
                //            break;
                //    }
                //    os += "Installed Language: " + lang + "\n";


                //    if (Convert.ToString(obj["Locale"]) == "0409")
                //    {
                //        os += "System Locale: " + "en-US" + "\n";
                //    }

                //    installDate_os = Convert.ToString(obj["InstallDate"]);
                //    {
                //        os += "Installed: " + ConvertToDateTimeSeconds(installDate_os) + "\n";
                //    }

                //    lastBootTime_os = Convert.ToString(obj["LastBootUpTime"]);
                //    {
                //        os += "LastBootUp: " + ConvertToDateTimeSeconds(lastBootTime_os) + "\n";
                //    }

                //    localeDateTime_os = Convert.ToString(obj["LocalDateTime"]);
                //    {
                //        os += "LocalDate: " + ConvertToDateTimeSeconds(localeDateTime_os) + "\n";
                //    }

                //}


                //var key = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall");


                //foreach (var v in key.GetSubKeyNames())
                //{
                //    string keyName = key + "\\" + v;
                //    var displayName = Registry.GetValue(keyName, "DisplayName", null);

                //    if (displayName != null)
                //    {
                //        software += "...............................\n";
                //        software +="DisplayName: " + displayName.ToString() + "\n";

                //        var ver = Registry.GetValue(keyName, "DisplayVersion", null);
                //        if (ver != null)
                //        {
                //            software += "Version: " + ver.ToString() +"\n";

                //        }
                //        var install = Registry.GetValue(keyName, "InstallLocation", null);
                //        if (install != null)
                //        {
                //            software += "Install Location: " + install.ToString() + "\n";

                //        }

                //    }
                //}


                //// get list of Windows services
                //ServiceController[] services = ServiceController.GetServices();

                //// try to find service name
                //foreach (ServiceController service in services)
                //{

                //    if (service.Status == ServiceControllerStatus.Running)
                //    {

                //        sService += "Name: " + service.ServiceName + "\n";
                //        sService += "Status: " + service.Status.ToString() + "\n";
                //    }


                //}
                //string fileLog = "SoftwareRp.txt";

                //using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileLog))
                //{
                //    w.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());
                //    w.WriteLine("===================================");
                //    w.WriteLine(os);
                //    w.WriteLine(software);
                //    w.WriteLine(sService);

                //}



                MessageBox.Show("Done");
        }

        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;
        }

        private void ServiceFn()
        {
            var wmiQueryString = "SELECT * FROM Win32_Service";
            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(wmiQueryString))
            using (ManagementObjectCollection coll = searcher.Get())
                foreach (ManagementObject sv in coll)
                {
                    string Name = "";
                    string ProcessId = "";
                    string State = "";
                    string Description = "";
                    foreach (PropertyData property in sv.Properties)
                    {
                        string svName = property.Name;
                        if (svName == "Name")
                        {
                            Name = property.Value.ToString();
                        }
                        if (svName == "ProcessId")
                        {
                            ProcessId = property.Value.ToString();
                        }
                        if (svName == "DisplayName")
                        {
                            Description = property.Value.ToString();
                        }
                        if (svName == "State")
                        {
                            State = property.Value.ToString();
                        }

                    }
                    if (State == "Running")
                    {
                        listService.Add(new cServiceInfo() { sName = Name, sStatus = State, sPID = ProcessId, sDescription = Description });

                    }
                }
        }
        private void ServiceInfo_Click(object sender, RoutedEventArgs e)
        {
            listService.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;

            ServiceFn();

            Lv_ServiceInfo.ItemsSource = listService;
            Lv_ServiceInfo.Visibility = Visibility.Visible;

        }

        private string SanitizeFormFactor(UInt16 i)
        {
            string result = string.Empty;

            switch (i)
            {
                case 0:
                    result = "Unknown";
                    break;
                case 1:
                    result = "Other";
                    break;
                case 2:
                    result = "SIP";
                    break;
                case 3:
                    result = "DIP";
                    break;
                case 4:
                    result = "ZIP";
                    break;
                case 5:
                    result = "SOJ";
                    break;
                case 6:
                    result = "Proprietary";
                    break;
                case 7:
                    result = "SIMM";
                    break;
                case 8:
                    result = "DIMM";
                    break;
                case 9:
                    result = "TSOP";
                    break;
                case 10:
                    result = "PGA";
                    break;
                case 11:
                    result = "RIMM";
                    break;
                case 12:
                    result = "SODIMM";
                    break;
                case 13:
                    result = "SRIMM";
                    break;
                case 14:
                    result = "SMD";
                    break;
                case 15:
                    result = "SSMP";
                    break;
                case 16:
                    result = "QFP";
                    break;
                case 17:
                    result = "TQFP";
                    break;
                case 18:
                    result = "SOIC";
                    break;
                case 19:
                    result = "LCC";
                    break;
                case 20:
                    result = "PLCC";
                    break;
                case 21:
                    result = "BGA";
                    break;
                case 22:
                    result = "FPBGA";
                    break;
                case 23:
                    result = "LGA";
                    break;
            }

            return result;
        }

        private string SanitizeMemoryType(UInt16 i)
        {
            string result = string.Empty;

            switch (i)
            {
                case 0:
                    result = "Unknown";
                    break;
                case 1:
                    result = "Other";
                    break;
                case 2:
                    result = "DRAM";
                    break;
                case 3:
                    result = "Synchonous DRAM";
                    break;
                case 4:
                    result = "Cache DRAM";
                    break;
                case 5:
                    result = "EDO";
                    break;
                case 6:
                    result = "EDRAM";
                    break;
                case 7:
                    result = "VRAM";
                    break;
                case 8:
                    result = "SRAM";
                    break;
                case 9:
                    result = "RAM";
                    break;
                case 10:
                    result = "ROM";
                    break;
                case 11:
                    result = "Flash";
                    break;
                case 12:
                    result = "EEPROM";
                    break;
                case 13:
                    result = "FEPROM";
                    break;
                case 14:
                    result = "EPROM";
                    break;
                case 15:
                    result = "CDRAM";
                    break;
                case 16:
                    result = "3DRAM";
                    break;
                case 17:
                    result = "SDRAM";
                    break;
                case 18:
                    result = "SGRAM";
                    break;
                case 19:
                    result = "RDRAM";
                    break;
                case 20:
                    result = "DDR";
                    break;
                case 21:
                    result = "DDR2";
                    break;
                case 22:
                    result = "DDR2 FB-DIMM";
                    break;
                case 24:
                    result = "DDR3";
                    break;
                case 25:
                    result = "FBD2";
                    break;
            }

            return result;
        }
        private void RamFn()
        {
            string ramQuery = string.Format("SELECT * from Win32_PhysicalMemory");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(ramQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject ram in coll)
                    {
                        foreach (PropertyData property in ram.Properties)
                        {
                            if (property.Name == "MemoryType")
                            {
                                UInt16 memorytype = Convert.ToUInt16(property.Value);
                                listRam.Add(new cRamInfo() { sRamItem = "Ram." + property.Name, sRamValue = SanitizeMemoryType(memorytype) });

                            }
                            else if (property.Name == "FormFactor")
                            {
                                UInt16 formfactor = Convert.ToUInt16(property.Value);
                                listRam.Add(new cRamInfo() { sRamItem = "Ram." + property.Name, sRamValue = SanitizeFormFactor(formfactor) });

                            }
                            else
                            {
                                if (property.Value != null)
                                {
                                    listRam.Add(new cRamInfo() { sRamItem = "Ram." + property.Name, sRamValue = Convert.ToString(property.Value) });

                                }

                            }

                        }

                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
                foreach (ManagementObject mo in searcher.Get())
                {
                    listRam.Add(new cRamInfo() { sRamItem = "VirtualMemory." + "TotalVirtualMemorySize", sRamValue = Convert.ToString(mo.Properties["TotalVirtualMemorySize"].Value) });
                    listRam.Add(new cRamInfo() { sRamItem = "VirtualMemory." + "AvailableVirtualMemory", sRamValue = Convert.ToString(mo.Properties["FreeVirtualMemory"].Value) });

                    var TotalVirtualMemory = Convert.ToUInt64(mo.Properties["TotalVirtualMemorySize"].Value);
                    var AvailableVirtualMemory = Convert.ToUInt64(mo.Properties["FreeVirtualMemory"].Value);
                    var UsedVirtualMemory = TotalVirtualMemory - AvailableVirtualMemory;

                    listRam.Add(new cRamInfo() { sRamItem = "VirtualMemory." + "UsedVirtualMemory", sRamValue = Convert.ToString(UsedVirtualMemory) });

                }
            }
            catch { }

        }
        private void RamInfo_Click(object sender, RoutedEventArgs e)
        {
            listRam.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;

            RamFn();

            //UInt16 pmType;
            //string type = "";
            //ManagementObjectSearcher pmQuery = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
            //ManagementObjectCollection pmCol = pmQuery.Get();
            //foreach (ManagementObject obj in pmCol)
            //{
            //    listItem.Add(new cRamInfo() { sRamItem = "Caption", sRamValue = obj["Caption"].ToString() });
            //    listItem.Add(new cRamInfo() { sRamItem = "Creation Class Name", sRamValue = obj["CreationClassName"].ToString() });

            //    listItem.Add(new cRamInfo() { sRamItem = "Manufacturer", sRamValue = obj["Manufacturer"].ToString() });

            //    //listItem.Add(new cRamInfo() { sRamItem = "Model", sRamValue = obj["Model"].ToString() });
            //    listItem.Add(new cRamInfo() { sRamItem = "Name", sRamValue = obj["Name"].ToString() });
            //    //listItem.Add(new cRamInfo() { sRamItem = "Other Identifying Info", sRamValue = obj["OtherIdentifyingInfo"].ToString() });
            //    listItem.Add(new cRamInfo() { sRamItem = "Part Number", sRamValue = obj["PartNumber"].ToString() });



            //    listItem.Add(new cRamInfo() { sRamItem = "Serial Number", sRamValue = obj["SerialNumber"].ToString() });
            //    //listItem.Add(new cRamInfo() { sRamItem = "SKU", sRamValue = obj["SKU"].ToString() });
            //    //listItem.Add(new cRamInfo() { sRamItem = "Status", sRamValue = obj["Status"].ToString() });
            //    listItem.Add(new cRamInfo() { sRamItem = "Tag", sRamValue = obj["Tag"].ToString() });
            //    //listItem.Add(new cRamInfo() { sRamItem = "Version", sRamValue = obj["Version"].ToString() });


            //    float c = Convert.ToUInt64(obj["Capacity"]) / (float)gb;
            //    decimal d = Decimal.Round(Convert.ToDecimal(c), 2);
            //    listItem.Add(new cRamInfo() { sRamItem = "Size", sRamValue = d.ToString() +" GB" });
            //    listItem.Add(new cRamInfo() { sRamItem = "Location", sRamValue = obj["DeviceLocator"].ToString() });
            //    listItem.Add(new cRamInfo() { sRamItem = "Datawidth", sRamValue = obj["Datawidth"].ToString() });
            //    listItem.Add(new cRamInfo() { sRamItem = "Clock Speed", sRamValue = obj["ConfiguredClockSpeed"].ToString() + " Megahertz" });

            //    pmType = Convert.ToUInt16(obj["TypeDetail"]);
            //    switch (pmType)
            //    {
            //        case 1:
            //            type = "Reserved";
            //            break;
            //        case 2:
            //            type = "Other";
            //            break;
            //        case 4:
            //            type = "Unknown";
            //            break;
            //        case 8:
            //            type = "Fast-Paged";
            //            break;
            //        case 16:
            //            type = "Static-Column";
            //            break;
            //        case 32:
            //            type = "Psuedo-static";
            //            break;
            //        case 64:
            //            type = "RAMBUS";
            //            break;
            //        case 128:
            //            type = "Synchronous";
            //            break;
            //        case 256:
            //            type = "CMOS";
            //            break;
            //        case 512:
            //            type = "EDO";
            //            break;
            //        case 1024:
            //            type = "Window DRAM";
            //            break;
            //        case 2048:
            //            type = "Cache DRAM";
            //            break;
            //        case 4096:
            //            type = "Non-volatile";
            //            break;
            //    }
            //    listItem.Add(new cRamInfo() { sRamItem = "Type", sRamValue = type });

            //}
            Lv_RamInfo.ItemsSource = listRam;
            Lv_RamInfo.Visibility = Visibility.Visible;

        }
        private string GetCPUNameAlternative()
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", false))
            {
                return key.GetValue("ProcessorNameString").ToString();
            }
        }
        private void CpuFn()
        {
            string cpuQuery = string.Format("SELECT * from Win32_Processor");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(cpuQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject cpu in coll)
                    {
                        foreach (PropertyData property in cpu.Properties)
                        {
                            if (property.Name == "Name")
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(property.Value)))
                                {
                                    listCpu.Add(new cCpuInfo() { sCpuItem = "CPU." + property.Name, sCpuValue = GetCPUNameAlternative() });

                                }

                            }
                            else
                            {
                                if (property.Value != null)
                                {
                                    listCpu.Add(new cCpuInfo() { sCpuItem = "CPU." + property.Name, sCpuValue = Convert.ToString(property.Value) });

                                }
                            }

                        }
                        try
                        {
                            ManagementObjectSearcher searcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
                            foreach (ManagementObject mo2 in searcher2.Get())
                            {
                                bool temp2 = Convert.ToBoolean(mo2.Properties["DataExecutionPrevention_Available"].Value);
                                listCpu.Add(new cCpuInfo() { sCpuItem = "CPU." + "DataExecutionPrevention_Available", sCpuValue = (temp2) ? "Yes" : "No" });

                            }
                        }
                        catch { }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            try
            {
                string gpuQuery = string.Format("SELECT * from Win32_VideoController");

                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(gpuQuery))
                using (ManagementObjectCollection coll = searcher.Get())
                {
                    try
                    {
                        int i = 0;
                        foreach (ManagementObject gpu in coll)
                        {
                            i++;
                            foreach (PropertyData property in gpu.Properties)
                            {
                                if (property.Name == "VideoMemoryType")
                                {
                                    UInt16 vtype = Convert.ToUInt16(property.Value);
                                    listCpu.Add(new cCpuInfo() { sCpuItem = $"GPU{i}." + property.Name, sCpuValue = SanitizeMemoryGpuType(vtype) });

                                }
                                else
                                {
                                    if (property.Value != null)
                                    {
                                        listCpu.Add(new cCpuInfo() { sCpuItem = $"GPU{i}." + property.Name, sCpuValue = Convert.ToString(property.Value) });

                                    }

                                }

                            }
                        }
                    }
                    catch (ManagementException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch { }

        }
        private void CpuInfo_Click(object sender, RoutedEventArgs e)
        {
            listCpu.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;


            CpuFn();

            //string processor = "";
            //string pfamily = "";

            //ManagementObjectSearcher proQuery = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
            //ManagementObjectCollection proCol = proQuery.Get();


            //foreach (ManagementObject obj in proCol)
            //{
            //    int processorF = Convert.ToUInt16(obj["Family"]);
            //    switch (processorF)
            //    {
            //        case 185:
            //            pfamily = "Intel(R) Pentium(R) M processor";
            //            break;
            //        case 186:
            //            pfamily = "Intel(R) Celeron(R) D processor";
            //            break;
            //        case 187:
            //            pfamily = "Intel(R) Pentium(R) D processor";
            //            break;
            //        case 188:
            //            pfamily = "Intel(R) Pentium(R) Processor Extreme Edition";
            //            break;
            //        case 189:
            //            pfamily = "Intel(R) Core(TM) Solo Processor";
            //            break;
            //        case 191:
            //            pfamily = "Intel(R) Core(TM)2 Duo Processor";
            //            break;
            //        case 192:
            //            pfamily = "Intel(R) Core(TM)2 Solo processor";
            //            break;
            //        case 193:
            //            pfamily = "Intel(R) Core(TM)2 Extreme processor";
            //            break;
            //        case 194:
            //            pfamily = "Intel(R) Core(TM)2 Quad processor";
            //            break;
            //        case 198:
            //            pfamily = "Intel(R) Core(TM) i7 processor";
            //            break;
            //        case 199:
            //            pfamily = "Dual-Core Intel(R) Celeron(R) Processor";
            //            break;
            //        case 205:
            //            pfamily = "Intel(R) Core(TM) i5 processor";
            //            break;
            //        case 206:
            //            pfamily = "Intel(R) Core(TM) i3 processor";
            //            break;
            //        default:
            //            pfamily = "Other";
            //            break;
            //    }
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Family", sCpuValue = pfamily });

            //    int arch = Convert.ToUInt16(obj["Architecture"]);
            //    switch (arch)
            //    {
            //        case 0:
            //            processor = "x86";
            //            break;
            //        case 1:
            //            processor = "MIPS";
            //            break;
            //        case 2:
            //            processor = "Alpha";
            //            break;
            //        case 3:
            //            processor = "POWER PC";
            //            break;
            //        case 5:
            //            processor = "ia64";
            //            break;
            //        case 6:
            //            processor = "Itanium-based systems";
            //            break;
            //        case 9:
            //            processor = "x64";
            //            break;
            //    }
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Caption", sCpuValue = obj["Caption"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Description", sCpuValue = obj["Description"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "DeviceID", sCpuValue = obj["DeviceID"].ToString() });
            //    //listItem.Add(new cCpuInfo() { sCpuItem = "ErrorDescription", sCpuValue = obj["ErrorDescription"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Name", sCpuValue = obj["Name"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "PartNumber", sCpuValue = obj["PartNumber"].ToString() });
            //   //listItem.Add(new cCpuInfo() { sCpuItem = "PNPDeviceID", sCpuValue = obj["PNPDeviceID"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "ProcessorId", sCpuValue = obj["ProcessorId"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Role", sCpuValue = obj["Role"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "SerialNumber", sCpuValue = obj["SerialNumber"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Status", sCpuValue = obj["Status"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "SocketDesignation", sCpuValue = obj["SocketDesignation"].ToString() });
            //    //listItem.Add(new cCpuInfo() { sCpuItem = "Stepping", sCpuValue = obj["Stepping"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "SystemCreationClassName", sCpuValue = obj["SystemCreationClassName"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "SystemName", sCpuValue = obj["SystemName"].ToString() });
            //    //listItem.Add(new cCpuInfo() { sCpuItem = "UniqueId", sCpuValue = obj["UniqueId"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Version", sCpuValue = obj["Version"].ToString() });


            //    listItem.Add(new cCpuInfo() { sCpuItem = "Architecture", sCpuValue = processor});
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Current Clock Speed", sCpuValue = Math.Round(((float)Convert.ToUInt32(obj["CurrentClockSpeed"]) / 1000), 2) + " GHz" });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Max Clock Speed", sCpuValue = Math.Round(((float)Convert.ToUInt32(obj["MaxClockSpeed"]) / 1000), 2) + " GHz" });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Multi Core", sCpuValue = obj["NumberOfCores"].ToString() });

            //    listItem.Add(new cCpuInfo() { sCpuItem = "L2CacheSize", sCpuValue = obj["L2CacheSize"].ToString() + " kilobyte primary memory cache" });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "L3CacheSize", sCpuValue = obj["L3CacheSize"].ToString() + " kilobyte primary memory cache" });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Logical Processor", sCpuValue = obj["NumberOfLogicalProcessors"].ToString() });
            //    listItem.Add(new cCpuInfo() { sCpuItem = "Bus Clock", sCpuValue = obj["ExtClock"].ToString() + " MHz" });

            //    listItem.Add(new cCpuInfo() { sCpuItem = "Asset Tag", sCpuValue = obj["AssetTag"].ToString() });

            //}
            Lv_CPUInfo.ItemsSource = listCpu;
            Lv_CPUInfo.Visibility = Visibility.Visible;

        }
        private async Task scanUrlFn()
        {
            string apiKey1 = "34e06aa1e69c5a2bd72d383f34e98f5e5691017654701c92345c4c42c132bdc1";
            string apiKey2 = "03b5102d54f8b0e32bffacd3dff8f1e1e3bb632ae2fc97858a7a759856fe69f8";
            string apiKey3 = "67261d55339eca17a87433401ff6618b5043c651bc5c0a36778eb4d1a6ab7d66";
            string apiKey4 = "7b80a0470af3cd3fc75d5cd72dc80695865544ae41d47863bee5d7e04716601e";
            string apiKey5 = "5cf75c07f82e33824cb62dacf84bd7017bacc2b26e34a17821f29d7b74216266";
            string apiKey6 = "991f46c9142bdca0cd482eb8b0ad9dc438c929215dc843c104dc2ada9ed0446f";
            string apiKey7 = "8f9164433b27279c943b26808f06764ee4ca8cd7de62bacc06b20240cc94ece5";
            string apiKey8 = "30d72bacf2b4c5b0547ed0fe71cfc15d11b7dec173f075202ce447edc21f5c07";
            string apiKey9 = "57828dd6442e803c2e70d12288dbe2bd56893e0a80e0178171a5fc5ac09e791c";
            string apikey10 = "67fcc3a4564cfe233ddca5bc165d7f79d4204035308d8809e2315881216da803";
            string apiKey11 = "195d0eeb2349b9cb9d3cc8289e8d85a20d3447bb4f0276d9932384b7c2bc761f";
            string apiKey12 = "35f68c90622fc84116ebbc742852837f78023aaca8837c4c2c90530ba72cc67d";


            string[] filePaths = Directory.GetFiles(m_exePath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(fileScanUrlLog))
                {
                    File.Delete(fileScanUrlLog);
                }
            }

            //List<string> browsers = new List<string>() { "chrome", "msedge" };
            //foreach (var item in browsers)
            //{
            List<String> listUrlscan = new List<String>();
            Process[] allChromeProcesses = Process.GetProcessesByName("chrome");
            Process[] mainChromes = allChromeProcesses.Where(p => !String.IsNullOrEmpty(p.MainWindowTitle)).ToArray();

            var uiaClassObject = new CUIAutomation();
            if (mainChromes.Length > 0)
            {
                IUIAutomationElement elm = uiaClassObject.ElementFromHandle(mainChromes[0].MainWindowHandle);
                //UIA_ControlTypePropertyId =30003, UIA_TabItemControlTypeId = 50019
                if (elm != null)
                {
                    IUIAutomationCondition chromeTabCondition = uiaClassObject.CreatePropertyCondition(30003, 50019);
                    IUIAutomationElementArray chromeTabCollection = elm.FindAll(TreeScope.TreeScope_Descendants, chromeTabCondition);
                    //UIA_LegacyIAccessiblePatternId = 10018, 0 -> Number of Chrome tab you want to activate
                    for (int i = 0; i < chromeTabCollection.Length; i++)
                    {

                        try
                        {
                            var lp = chromeTabCollection.GetElement(i).GetCurrentPattern(10018) as IUIAutomationLegacyIAccessiblePattern;
                            lp.DoDefaultAction();
                            //MessageBox.Show("Done");
                            IUIAutomationCondition Cond = uiaClassObject.CreatePropertyCondition(30003, 50004);
                            IUIAutomationElement elm2 = elm.FindFirst(TreeScope.TreeScope_Descendants, Cond);
                            //lp2.SupportedTextSelection();
                            IUIAutomationValuePattern val = (IUIAutomationValuePattern)elm2.GetCurrentPattern(10002);
                            char dot = '.';
                            if (val.CurrentValue != "" && val.CurrentValue.Length > 10 && val.CurrentValue.Contains(dot))
                            {

                                listUrlscan.Add(val.CurrentValue);

                            }
                        }
                        catch { }


                    }
                }
            }
            List<string> uniqueList = listUrlscan.Distinct().ToList();
            var roundRobinList = new RoundRobinList<string>(new List<string> { apiKey1, apiKey2, apiKey3, apiKey4, apiKey5, apiKey6, apiKey7, apiKey8, apiKey9, apikey10, apiKey11, apiKey12 });

            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileScanUrlLog))
            {
                w.WriteLine("=========================List of malicious urls ================");
            }
            foreach (string url in uniqueList)
            {
                string apiKey = roundRobinList.Next();


                string url_http = string.Empty;
                string url_https = string.Empty;
                if (url.Contains("https"))
                {

                    url_https = url;
                }
                else if (url.Contains("http"))
                {
                    url_http = url;
                }
                else
                {
                    url_http = "http://" + url;
                    url_https = "https://" + url;
                }
                if (url_http != "")
                {

                    await scanUrl(m_exePath, url_http, apiKey);

                }
                if (url_https != "")
                {

                    await scanUrl(m_exePath, url_https, apiKey);

                }

            }
        }
        private async void ScanUrl_Click(object sender, RoutedEventArgs e)
        {
            listUrl.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;
            //string url1 = "http://lasopajar764.weebly.com/yakyuken-special-2-psx-rom.html";
            //string url2 = "https://ianrosenwach.com/tag/beats/";
            // string url3 = "https://bafybeiaxo2xooq2fdui36ypunm7u3mcxrh2w372pja57wzfi2iowamuoni.ipfs.dweb.link/link.html";
            //http://zemsta.andrzejwajda.pl/wp-admin/js/edit-comments.min.js?ver=5.5.8
            //http://phimxh.com/p/star-movie.html

            await scanUrlFn();

            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileScanUrlLog))
            {
               
                if (listUrl.Count == 0)
                {
                    MessageBox.Show("No malicious url, all ok.");
                    w.WriteLine("No malicious url, all ok.");
                }
            }
            Scan_Url.ItemsSource = listUrl;
            Scan_Url.Visibility = Visibility.Visible;
        }

        private async Task scanUrl(string m_exePath, string scanUrl, string apiKey)
        {

            int detected = 0;
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileScanUrlLog))
            {
                VirusTotal virusTotal = new VirusTotal(apiKey);
                virusTotal.UseTLS = true;
                //w.WriteLine("Url: "+ scanUrl);
                UrlReport urlReport = await virusTotal.GetUrlReportAsync(scanUrl);

                bool hasUrlBeenScannedBefore = urlReport.ResponseCode == UrlReportResponseCode.Present;
                //w.WriteLine("URL has been scanned before: " + (hasUrlBeenScannedBefore ? "Yes" : "No"));

                //If the url has been scanned before, the results are embedded inside the report.
                if (hasUrlBeenScannedBefore)
                {
                   // w.WriteLine("Scan ID: " + urlReport.ScanId);
                   // w.WriteLine("Message: " + urlReport.VerboseMsg);

                    if (urlReport.ResponseCode == UrlReportResponseCode.Present)
                    {
                        foreach (KeyValuePair<string, UrlScanEngine> scan in urlReport.Scans)
                        {
                           // w.WriteLine("{0,-25} Detected: {1}", scan.Key, scan.Value.Detected);
                            if(scan.Value.Detected)
                            {
                                detected++;
                            }    
                        }
                        

                    }

                    //w.WriteLine();
                }
                else
                {
                    UrlScanResult urlResult = await virusTotal.ScanUrlAsync(scanUrl);
                    //w.WriteLine("Scan ID: " + urlResult.ScanId);
                    //w.WriteLine("Message: " + urlResult.VerboseMsg);
                    //w.WriteLine();
                }

                if (detected > 0)
                {
                    listUrl.Add(new cScanUrlInfo() { sUrl = scanUrl, sDetected = detected.ToString() + " Anti virus" });
                    MessageBox.Show(scanUrl + "\nDetected by " + detected.ToString() + " Anti virus");
                    w.WriteLine("----------------------------------------------------------------");

                }
            }

           


        }

        private async Task ScanMalwareFn()
        {
            string apiKey1 = "34e06aa1e69c5a2bd72d383f34e98f5e5691017654701c92345c4c42c132bdc1";
            string apiKey2 = "03b5102d54f8b0e32bffacd3dff8f1e1e3bb632ae2fc97858a7a759856fe69f8";
            string apiKey3 = "67261d55339eca17a87433401ff6618b5043c651bc5c0a36778eb4d1a6ab7d66";
            string apiKey4 = "7b80a0470af3cd3fc75d5cd72dc80695865544ae41d47863bee5d7e04716601e";
            string apiKey5 = "5cf75c07f82e33824cb62dacf84bd7017bacc2b26e34a17821f29d7b74216266";
            string apiKey6 = "991f46c9142bdca0cd482eb8b0ad9dc438c929215dc843c104dc2ada9ed0446f";
            string apiKey7 = "8f9164433b27279c943b26808f06764ee4ca8cd7de62bacc06b20240cc94ece5";
            string apiKey8 = "30d72bacf2b4c5b0547ed0fe71cfc15d11b7dec173f075202ce447edc21f5c07";
            string apiKey9 = "57828dd6442e803c2e70d12288dbe2bd56893e0a80e0178171a5fc5ac09e791c";
            string apikey10 = "67fcc3a4564cfe233ddca5bc165d7f79d4204035308d8809e2315881216da803";
            string apiKey11 = "195d0eeb2349b9cb9d3cc8289e8d85a20d3447bb4f0276d9932384b7c2bc761f";
            string apiKey12 = "35f68c90622fc84116ebbc742852837f78023aaca8837c4c2c90530ba72cc67d";

            List<cFileScan> listFilescan = new List<cFileScan>();
            string[] filePaths = Directory.GetFiles(m_exePath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(fileScanMalwareLog))
                {
                    File.Delete(fileScanMalwareLog);
                }
            }

            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileScanMalwareLog))
            {
                w.WriteLine("=========================List of Malware ================");
                var wmiQueryString = "SELECT ProcessId, ExecutablePath, CommandLine FROM Win32_Process";
                using (var searcher = new ManagementObjectSearcher(wmiQueryString))
                using (var results = searcher.Get())
                {
                    var query = from p in Process.GetProcesses()
                                join mo in results.Cast<ManagementObject>()
                                on p.Id equals (int)(uint)mo["ProcessId"]
                                select new
                                {
                                    Process = p,
                                    Path = (string)mo["ExecutablePath"],
                                };
                    foreach (var item in query)
                    {
                        if (item.Path != null)
                        {
                            listFilescan.Add(new cFileScan() { sId = item.Process.Id.ToString(), sName = item.Process.ProcessName, sValue = item.Path });
                            //listFile.Add(new cProcessInfo() { sId = item.Process.Id.ToString(), sName = item.Process.ProcessName, sValue = item.Path });

                        }
                    }
                }
            }

            List<cFileScan> uniqueList = listFilescan.Distinct(new FileScanComparer()).ToList();
            var roundRobinList = new RoundRobinList<string>(new List<string> { apiKey1, apiKey2, apiKey3, apiKey4, apiKey5, apiKey6, apiKey7, apiKey8, apiKey9, apikey10, apiKey11, apiKey12 });

            foreach (cFileScan file in uniqueList)
            {
                string apiKey = roundRobinList.Next();

                await scanMalware(m_exePath, file.sId, file.sName, file.sValue, apiKey);

            }

           
        }
        private async void MalwareScan_Click(object sender, RoutedEventArgs e)
        {
            listFile.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;

            await ScanMalwareFn();

            if (listFile.Count == 0)
            {
                MessageBox.Show("No malware. All ok.");
            }
            Lv_ScanMalwareInfo.ItemsSource = listFile;
            Lv_ScanMalwareInfo.Visibility = Visibility.Visible;

            
        }
        static string CalculateMD5(string filename)
        {
            using (var md5 = MD5.Create())
            {
                using (var stream = File.OpenRead(filename))
                {
                    var hash = md5.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }
        }
        private async Task scanMalware(string m_exePath, string sId, string name,  string scanFile, string apiKey)
        {
            
            int detected = 0;
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + fileScanMalwareLog))
            {
               
                VirusTotal virusTotal = new VirusTotal(apiKey);
                virusTotal.UseTLS = true;
                
                string hashFile = CalculateMD5(scanFile);
                //w.WriteLine("Scan file: " + scanFile);
               
               FileReport fileReport = await virusTotal.GetFileReportAsync(hashFile);

                bool hasFileBeenScannedBefore = fileReport.ResponseCode == FileReportResponseCode.Present;

                //w.WriteLine("File has been scanned before: " + (hasFileBeenScannedBefore ? "Yes" : "No"));

                //If the url has been scanned before, the results are embedded inside the report.
                if (hasFileBeenScannedBefore)
                {
                    //w.WriteLine("Scan ID: " + fileReport.ScanId);
                   // w.WriteLine("Message: " + fileReport.VerboseMsg);

                    if (fileReport.ResponseCode == FileReportResponseCode.Present)
                    {
                        foreach (KeyValuePair<string, ScanEngine> scan in fileReport.Scans)
                        {
                            //w.WriteLine("{0,-25} Detected: {1}", scan.Key, scan.Value.Detected);
                            if (scan.Value.Detected)
                            {
                                detected++;
                            }
                        }
                    }

                    //w.WriteLine();
                }
                else
                {
                    ScanResult fileResult = await virusTotal.ScanFileAsync(scanFile);
                   
                    //w.WriteLine("Scan ID: " + fileResult.ScanId);
                    //w.WriteLine("Message: " + fileResult.VerboseMsg);
                    //w.WriteLine();
                }

                if (detected > 0)
                {
                   
                    listFile.Add(new cProcessInfo() { sId = sId, sName = name, sValue=  scanFile, sDetected = detected.ToString() + " Anti virus" });
                    MessageBox.Show(scanFile + "\nDetected by " + detected.ToString() + " Anti virus");
                    w.WriteLine(scanFile + "\nDetected by " + detected.ToString() + " Anti virus");
                    w.WriteLine("----------------------------------------------------------------");
                }


            }

        }
        private string SanitizeDeviceInterface(UInt16 i)
        {
            string result = string.Empty;

            switch (i)
            {
                case 1:
                    result = "Other";
                    break;
                case 2:
                    result = "Unknown";
                    break;
                case 3:
                    result = "Serial";
                    break;
                case 4:
                    result = "PS/2";
                    break;
                case 5:
                    result = "Infrared";
                    break;
                case 6:
                    result = "HP-HIL";
                    break;
                case 7:
                    result = "Bus mouse";
                    break;
                case 8:
                    result = "ADB (Apple Desktop Bus)";
                    break;
                case 160:
                    result = "Bus mouse DB-9";
                    break;
                case 161:
                    result = "Bus mouse micro-DIN";
                    break;
                case 162:
                    result = "USB";
                    break;
            }

            return result;
        }

        private string SanitizePointingType(UInt16 i)
        {
            string result = string.Empty;

            switch (i)
            {
                case 1:
                    result = "Other";
                    break;
                case 2:
                    result = "Unknown";
                    break;
                case 3:
                    result = "Mouse";
                    break;
                case 4:
                    result = "Track Ball";
                    break;
                case 5:
                    result = "Track Point";
                    break;
                case 6:
                    result = "Glide Point";
                    break;
                case 7:
                    result = "Touch Pad";
                    break;
                case 8:
                    result = "Touch Screen";
                    break;
                case 9:
                    result = "Mouse - Optical Sensor";
                    break;
            }

            return result;
        }

        private void PeripheralsFn()
        {
            string keyboardQuery = string.Format("SELECT * from Win32_Keyboard");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(keyboardQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject keyboard in coll)
                    {
                        foreach (PropertyData property in keyboard.Properties)
                        {
                            if (property.Value != null)
                            {
                                listPPr.Add(new cPPrInfo() { sPPrItem = "Keyboard." + property.Name, sPPrValue = Convert.ToString(property.Value) });
                            }

                        }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            string pointerQuery = string.Format("SELECT * from Win32_PointingDevice");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(pointerQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject pointer in coll)
                    {
                        foreach (PropertyData property in pointer.Properties)
                        {
                            if (property.Name == "PointingType")
                            {
                                UInt16 i = Convert.ToUInt16(property.Value);
                                listPPr.Add(new cPPrInfo() { sPPrItem = "Pointer." + property.Name, sPPrValue = SanitizePointingType(i) });
                            }
                            else if (property.Name == "DeviceInterface")
                            {
                                UInt16 i2 = Convert.ToUInt16(property.Value);
                                listPPr.Add(new cPPrInfo() { sPPrItem = "Pointer." + property.Name, sPPrValue = SanitizeDeviceInterface(i2) });

                            }
                            else
                            {
                                if (property.Value != null)
                                {
                                    listPPr.Add(new cPPrInfo() { sPPrItem = "Pointer." + property.Name, sPPrValue = Convert.ToString(property.Value) });

                                }

                            }

                        }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            string usbConQuery = string.Format("SELECT * from Win32_USBController");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(usbConQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject usb in coll)
                    {
                        foreach (PropertyData property in usb.Properties)
                        {
                            if (property.Value != null)
                            {
                                listPPr.Add(new cPPrInfo() { sPPrItem = "USB." + property.Name, sPPrValue = Convert.ToString(property.Value) });

                            }

                        }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }


            string query = string.Format("SELECT * from Win32_Printer");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(query))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject printer in coll)
                    {
                        foreach (PropertyData property in printer.Properties)
                        {
                            if (property.Value != null)
                            {
                                listPPr.Add(new cPPrInfo() { sPPrItem = "Printer." + property.Name, sPPrValue = Convert.ToString(property.Value) });

                            }

                        }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Peripherals_Click(object sender, RoutedEventArgs e)
        {
            listPPr.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;


            PeripheralsFn();


            Lv_PPrInfo.ItemsSource = listPPr;
            Lv_PPrInfo.Visibility = Visibility.Visible;

        }
        private string SanitizeDriveType(UInt32 i)
        {
            string result = string.Empty;

            switch (i)
            {
                case 0:
                    result = "Unknown";
                    break;
                case 1:
                    result = "No Root Directory";
                    break;
                case 2:
                    result = "Removable Disk";
                    break;
                case 3:
                    result = "Local Disk";
                    break;
                case 4:
                    result = "Network Drive";
                    break;
                case 5:
                    result = "Compact Disk";
                    break;
                case 6:
                    result = "RAM Disk";
                    break;
            }

            return result;
        }

        private void DriveFn()
        {
            string disksQuery = string.Format("SELECT * from Win32_DiskDrive");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(disksQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject disk in coll)
                    {
                        foreach (PropertyData property in disk.Properties)
                        {
                            if (property.Value != null)
                            {
                                listDrive.Add(new cDriveInfo() { sDriveItem = "Disk." + property.Name, sDriveValue = Convert.ToString(property.Value) });

                            }

                        }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            string volumeQuery = string.Format("SELECT * from Win32_Volume");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(volumeQuery))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject volume in coll)
                    {
                        foreach (PropertyData property in volume.Properties)
                        {
                            if (property.Name == "DriveType")
                            {
                                UInt32 i = Convert.ToUInt32(property.Value);
                                listDrive.Add(new cDriveInfo() { sDriveItem = "Volume." + property.Name, sDriveValue = SanitizeDriveType(i) });

                            }
                            else
                            {
                                if (property.Value != null)
                                {
                                    listDrive.Add(new cDriveInfo() { sDriveItem = "Volume." + property.Name, sDriveValue = Convert.ToString(property.Value) });

                                }

                            }
                        }
                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Drive_Click(object sender, RoutedEventArgs e)
        {
            listDrive.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;

            DriveFn();
            Lv_DriveInfo.ItemsSource = listDrive;
            Lv_DriveInfo.Visibility = Visibility.Visible;

        }
        private void ScanDigitalSignFn()
        {
            string[] filePaths = Directory.GetFiles(m_exePath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(ScanDigitalSign))
                {
                    File.Delete(ScanDigitalSign);
                }
            }

            
            var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths");
          
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + ScanDigitalSign))
            {
                w.WriteLine("=========================List of file without digital signature================");
                foreach (var v in key.GetSubKeyNames())
                {
                    string keyName = key + "\\" + v;
                    var Path = Registry.GetValue(keyName, "Path", null);
                    if (Path != null)
                    {
                        string strPath = Path.ToString();
                        char last = strPath[strPath.Length - 1];
                        char slash = '\\';
                        if (last.CompareTo(slash) == 0)
                        {
                            strPath = strPath + v;

                        }
                        else
                        {
                            strPath = strPath + '\\' + v;
                        }
                        //string filepath = @"C:\Users\tinhc\Downloads\Garena -v2.0-VN.exe";

                        if (!IsSigned(strPath))
                        {
                            listScanSign.Add(new cSignInfo() { sSignPath = strPath, sSignState = "No Signed" });
                            w.WriteLine(strPath);
                            w.WriteLine("---------------------------------------------------");

                           
                        }

                    }
                }
            }
        }
        public static bool IsSigned(string filepath)
        {
            try
            {
                
                Runspace runSpace = RunspaceFactory.CreateRunspace();
                runSpace.Open();

                Pipeline pipeline = runSpace.CreatePipeline();

                pipeline.Commands.AddScript("Get-AuthenticodeSignature \"" + filepath + "\"");

              
                if (pipeline != null)
                {
                    Collection<PSObject> output = pipeline.Invoke();
                    foreach (PSObject psObject in output)
                    {
                        System.Management.Automation.Signature signature = (System.Management.Automation.Signature)psObject.BaseObject;
                        if (signature.Status.ToString().Equals("Valid"))
                        {
                            return true;
                        }
                    }
                }
                
                   
                return false;
            }
            catch
            {

                return false;
            }
            
            

           
            //    //RunspaceConfiguration runspaceConfiguration = RunspaceConfiguration.Create();
            //    Runspace runspace = RunspaceFactory.CreateRunspace();
            //    runspace.Open();

            //    Pipeline pipeline = runspace.CreatePipeline();
            //    pipeline.Commands.AddScript("Get-AuthenticodeSignature \"" + filepath + "\"");

            //    Collection results = pipeline.Invoke();
            //    runspace.Close();
            //    System.Management.Automation.Signature signature = results[0].BaseObject as System.Management.Automation.Signature;
            //    return signature == null ? false : (signature.Status != SignatureStatus.NotSigned);
            //}
            
        }
        private void Scan_Signature_Click(object sender, RoutedEventArgs e)
        {
            listScanSign.Clear();

            Lv_MainboardInfo.Visibility = Visibility.Hidden;
            Lv_RamInfo.Visibility = Visibility.Hidden;
            Lv_CPUInfo.Visibility = Visibility.Hidden;
            Lv_DriveInfo.Visibility = Visibility.Hidden;
            Lv_PPrInfo.Visibility = Visibility.Hidden;
            Lv_OSInfo.Visibility = Visibility.Hidden;
            Lv_ServiceInfo.Visibility = Visibility.Hidden;
            Lv_SoftwareInfo.Visibility = Visibility.Hidden;
            Lv_ScanMalwareInfo.Visibility = Visibility.Hidden;
            Scan_Url.Visibility = Visibility.Hidden;
            Lv_NoSign.Visibility = Visibility.Hidden;

            ScanDigitalSignFn();



            MessageBox.Show("Have " + listScanSign.Count + " Application were not Signed Digital Signature!!!");

            //string filepath = @"C:\Users\tinhc\Downloads\SEB_3.4.1.505_x64_Setup.msi";

            Lv_NoSign.ItemsSource = listScanSign;
            Lv_NoSign.Visibility = Visibility.Visible;

        }

        private async void SecurityRP_Click(object sender, RoutedEventArgs e)
        {
            string[] filePaths = Directory.GetFiles(m_exePath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(securityRP))
                {
                    File.Delete(securityRP);
                }
            }
            using (StreamWriter w = File.AppendText(m_exePath + "\\" + securityRP))
            {
                w.WriteLine("========================= Information Security Report ================");
                w.WriteLine();

                if (listFile.Count <= 0)
                {
                   await ScanMalwareFn();
                }
                w.WriteLine("--------------------- Scan Malware --------------------------");
                w.WriteLine("\t------------------------------------------------------");
                foreach (cProcessInfo process in listFile)
                {
                    w.WriteLine("Name:\t" + process.sName);
                    w.WriteLine("pId:\t" + process.sId);
                    w.WriteLine("Path:\t" + process.sValue);
                    w.WriteLine("Detecte by:\t" + process.sDetected);
                    w.WriteLine(".........................................................");
                }

                if (listUrl.Count <= 0)
                {
                    await scanUrlFn();
                }
                w.WriteLine("--------------------- Scan Url --------------------------");
                w.WriteLine("\t------------------------------------------------------");
                foreach (cScanUrlInfo url in listUrl)
                {
                    w.WriteLine("Url:\t" + url.sUrl);
                    w.WriteLine("pId:\t" + url.sDetected);
                    w.WriteLine(".........................................................");
                }

                if (listScanSign.Count <= 0)
                {
                   ScanDigitalSignFn();
                }
                w.WriteLine("--------------------- Scan Digtal Signature --------------------------");
                w.WriteLine("\t------------------------------------------------------");
                foreach (cSignInfo sign in listScanSign)
                {
                    w.WriteLine("Path:\t" + sign.sSignPath);
                    w.WriteLine("State:\t" + sign.sSignState);

                    w.WriteLine(".........................................................");
                }
            }
            MessageBox.Show("Done");


        }
    }
}
